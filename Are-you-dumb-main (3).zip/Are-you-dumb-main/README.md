# Are-you-dumb

Inspired by <a href="https://www.instagram.com/3coder/" target="_blank">@3coder</a>

Link to project : <a href="https://are-you-dumb.courqu.in/" target="_blank">are-you-dumb.courqu.in/</a>